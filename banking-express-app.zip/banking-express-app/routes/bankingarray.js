var express = require('express');
var router = express.Router();


var accounts=[
    {accno:101,name:'Sachin Tendulkar',balance:4166544.43333,doc:new Date()},
    {accno:102,name:'Pradeep Chinchole',balance:4266544.43333,doc:new Date()},
    {accno:103,name:'Prakash Chougule',balance:4866544.43333,doc:new Date()},
    {accno:104,name:'Mahesh Rajput',balance:4666544.43333,doc:new Date()},
    {accno:105,name:'Mohan Bhagwat',balance:6566544.43333,doc:new Date()},
];


/* GET all accounts */
router.get('/accounts', function(req, res, next) {
  res.json(accounts);
});


/* GET account by accno */
router.get('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);
    var account=accounts.filter((account)=>account.accno==accno)[0];
   res.json(account);
});
  

/* delete account by accno */
router.delete('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);
    accounts=accounts.filter((account)=>account.accno!=accno);
    res.json(accounts);
});

/* update account by accno */
router.put('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);

    var name=req.body.name;
    var balance=parseFloat(req.body.balance);
    var doc=req.body.doc;
          

    accounts.forEach((account,index)=>{
      if(account.accno==accno)
       {
        accounts[index].name=name;
        accounts[index].balance=balance;
        accounts[index].doc=doc;
       }

    });
  

    res.json(accounts);
});



/* update account by accno */
router.post('/accounts', function(req, res, next) {
    var account=req.body;

    console.log("Account :",account)

    accounts.push(account);
    
    res.json(accounts);
});



module.exports = router;
