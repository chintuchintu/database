var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
    var userid=req.query.userid;
    var pwd=req.query.pwd;
    
  res.send('GET :Hello '+userid+"  your passwrod is :"+pwd);
});


/* GET users listing. */
router.post('/', function(req, res, next) {

    var userid=req.body.userid;
    var pwd=req.body.pwd;
    
  res.send('POST :Hello '+userid+"  your passwrod is :"+pwd);


    res.send('respond with a resource');
  });
  
  

module.exports = router;
