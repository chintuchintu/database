var express = require('express');

var mongoose = require('mongoose');

var router = express.Router();
var dbURL="mongodb://localhost:27017/bank";


//establsihe the connection

mongoose.connect(dbURL);


mongoose.connection.on('connected', function(){
    console.log("Mongoose default connection is open to ", dbURL);
});

mongoose.connection.on('error', function(err){
    console.log("Mongoose default connection has occured "+err+" error");
});

mongoose.connection.on('disconnected', function(){
    console.log("Mongoose default connection is disconnected");
});


var Schema = mongoose.Schema;

var accountSchema = new Schema({
    accno :{
        type: Number,
        unique : true,
        required : true
        },
        name :{
            type: String,
            unique : false,
            required : true
            },

            balance :{
                type: Number,
                unique : false,
                required : true
                },
                doc:{
                    type: Date,
                    unique : false,
                    required : false
                    }
});
                

var accountModel=mongoose.model('account', accountSchema);


/* GET all accounts */
router.get('/accounts', function(req, res, next) {

    accountModel.find({},function(err,data){
        res.json(data);
     });
   
  
});


/* GET account by accno */
router.get('/accounts/:accno', function(req, res, next) {
    var acc_no=parseInt(req.params.accno);

    accountModel.findOne({accno:acc_no},function(err,data){
        res.json(data);
     });
   
});
  

/* delete account by accno */
router.delete('/accounts/:accno', function(req, res, next) {
    var acc_no=parseInt(req.params.accno);


    accountModel.remove({accno:acc_no},function(err,data){
        
        if(err)
        res.send(""+err);

        accountModel.find({},function(err,data){
            res.json(data);
         }); 

     });
   
});

/* update account by accno */
router.put('/accounts/:accno', function(req, res, next) {
    var acc_no=parseInt(req.params.accno);

    accountModel.findOne({accno:acc_no},function(err,data){

    
        for(prop in req.body){
          data[prop]=req.body[prop];
          }
  
    
    
         data.save(function(error){
            if(error)
            res.send(""+error);
    
            accountModel.find({},function(err,data){
                res.json(data);
             });
    
          });
    
       });
    
});



/* update account by accno */
router.post('/accounts', function(req, res, next) {
    var account=new accountModel(req.body);


    account.save(function(error){
      if(error)
      res.send(""+error);

      accountModel.find({},function(err,data){
          res.json(data);
       });

    });
});



module.exports = router;
